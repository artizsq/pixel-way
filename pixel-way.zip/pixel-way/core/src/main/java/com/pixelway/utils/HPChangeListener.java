package com.pixelway.utils;

public interface HPChangeListener {
    void onHPchanged(int HP);
}
