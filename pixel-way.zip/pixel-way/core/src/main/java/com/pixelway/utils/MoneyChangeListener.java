package com.pixelway.utils;

public interface MoneyChangeListener {
    void onMoneyChanged(int newMoney);
}
