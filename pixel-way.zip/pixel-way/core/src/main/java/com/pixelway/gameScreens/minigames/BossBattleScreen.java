package com.pixelway.gameScreens.minigames;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.pixelway.MainClass;
import com.pixelway.map.BossWorldManager;
import com.pixelway.map.TiledObjectsConverter;
import com.pixelway.models.Boss;
import com.pixelway.models.BossAttack;
import com.pixelway.models.Boulder;
import com.pixelway.models.MiniPlayer;
import com.pixelway.models.PlayerBullet;
import com.pixelway.models.Shard;
import com.pixelway.utils.VirtualJoystick;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BossBattleScreen implements Screen {

    private final MainClass game;
    private OrthographicCamera gameCamera;
    private OrthographicCamera uiCamera;

    private TiledMap tiledMap;
    private Array<Fixture> fixtures;
    private OrthogonalTiledMapRenderer renderer;
    private BossWorldManager bossWorldManager;
    private Box2DDebugRenderer debugRenderer;
    private SpriteBatch batch;

    private Boss boss;
    private MiniPlayer miniPlayer;
    private VirtualJoystick joystick;
    private Stage uiStage;
    private ImageButton mainButton;

    // Для атак босса
    private List<BossAttack> bossAttacks = new ArrayList<>();
    private float attackTimer = 0f;
    private float attackInterval = 2f; // Начальный интервал
    private Texture shardTexture;
    private Texture boulderTexture;

    // Границы поля игрока, где будут спавниться атаки босса
    private static final float PLAYER_AREA_MIN_X = 495;

    private static final float PLAYER_AREA_MAX_X = 783;

    private static final float PLAYER_AREA_MIN_Y = 113;

    private static final float PLAYER_AREA_MAX_Y = 398;



// Для спавна атак босса сверху для осколков

    private static final float SHARD_SPAWN_Y = 398;



// Для спавна атак босса слева/справа для булыжников

    private static final float BOULDER_SPAWN_LEFT_X = 495;

    private static final float BOULDER_SPAWN_RIGHT_X = 760;

    private static final float BOULDER_SPAWN_Y_RANGE_MIN = 150;

    private static final float BOULDER_SPAWN_Y_RANGE_MAX = 350;


    private static final int PHASE_ONE_THRESHOLD = 750; // 1000 - 751 HP (Осколки)
    private static final int PHASE_TWO_THRESHOLD = 500; // 750 - 501 HP (Булыжники)
    // 500 - 0 HP (Все вместе)


    // Список тел для безопасного удаления Box2D тел после шага симуляции.
    private List<com.badlogic.gdx.physics.box2d.Body> bodiesToDestroy = new ArrayList<>();

    public BossBattleScreen(MainClass game) {
        this.game = game;
        this.bossWorldManager = new BossWorldManager();
    }

    @Override
    public void show() {
        tiledMap = new TmxMapLoader().load("maps/bossFight.tmx");
        renderer = new OrthogonalTiledMapRenderer(tiledMap);
        batch = new SpriteBatch();

        gameCamera = new OrthographicCamera();
        gameCamera.setToOrtho(false, 1280, 720); // Размеры вашего игрового мира
        gameCamera.position.set(640, 360, 0); // Центрируем камеру
        gameCamera.update();

        // Инициализируем Босса и Игрока
        // Убедитесь, что Boss инициализируется с полным здоровьем (BOSS_MAX_HP)
        boss = new Boss(new Vector2(550, 450), 200f, 200f, bossWorldManager.getWorld());
        miniPlayer = new MiniPlayer(new Vector2(645, 235), 32f, 32f, bossWorldManager.getWorld(), game);

        // Устанавливаем наш внутренний ContactListener для обработки столкновений
        bossWorldManager.getWorld().setContactListener(new BossFightContactListener());

        // Импортируем объекты столкновений из Tiled карты
        fixtures = TiledObjectsConverter.bossImportObjects(tiledMap, bossWorldManager, 1);
        debugRenderer = new Box2DDebugRenderer();

        // Загружаем текстуры для атак босса
        shardTexture = new Texture(Gdx.files.internal("texture/boss/attack2.png"));
        boulderTexture = new Texture(Gdx.files.internal("texture/boss/attack1.png"));

        // Настройка UI камеры и Stage
        uiCamera = new OrthographicCamera();
        uiCamera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        uiCamera.update();
        uiStage = new Stage(new ScreenViewport(uiCamera));

        // Обработка ввода с мультиплексором для UI и игрового ввода (джойстик)
        InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(uiStage);
        Gdx.input.setInputProcessor(multiplexer);

        // Настройка кнопки стрельбы
        TextureRegionDrawable buttonDrawable = new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("texture/boss/shoot.png"))));
        buttonDrawable.setMinSize(240, 240);
        mainButton = new ImageButton(buttonDrawable);
        mainButton.setBounds(Gdx.graphics.getWidth() - 480, 20, 240 * 2f, 240 * 2f); // Позиция и размер
        mainButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                miniPlayer.shoot(); // Игрок стреляет при нажатии кнопки
            }
        });
        uiStage.addActor(mainButton);

        joystick = new VirtualJoystick(242, 300, 240, 100, game);
        uiStage.addActor(joystick);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        for (com.badlogic.gdx.physics.box2d.Body body : bodiesToDestroy) {
            if (bossWorldManager.getWorld().getBodyCount() > 0 && !bossWorldManager.getWorld().isLocked()) {
                bossWorldManager.getWorld().destroyBody(body);
            }
        }
        bodiesToDestroy.clear();

        bossWorldManager.getWorld().step(1 / 60f, 6, 2);

        gameCamera.update();
        renderer.setView(gameCamera);
        renderer.render();

        batch.setProjectionMatrix(gameCamera.combined);
        batch.begin();
        boss.render(batch);
        miniPlayer.render(batch);

        for (BossAttack attack : bossAttacks) {
            attack.render(batch);
        }
        batch.end();

        uiStage.act(delta);
        uiStage.draw();

        miniPlayer.update(delta, joystick.getDirection());
        boss.update(delta);

        Iterator<PlayerBullet> playerBulletIterator = miniPlayer.getBullets().iterator();
        while (playerBulletIterator.hasNext()) {
            PlayerBullet bullet = playerBulletIterator.next();
            bullet.update(delta);
            if (bullet.isMarkedForRemoval()) {
                bodiesToDestroy.add(bullet.getBody());
                playerBulletIterator.remove();
            }
        }

        Iterator<BossAttack> attackIterator = bossAttacks.iterator();
        while (attackIterator.hasNext()) {
            BossAttack attack = attackIterator.next();
            attack.update(delta);
            if (attack.isMarkedForRemoval()) {
                bodiesToDestroy.add(attack.getBody());
                attackIterator.remove();
            }
        }

        attackTimer += delta;
        if (attackTimer >= attackInterval) {
            spawnBossAttacksBasedOnHealth();
            attackTimer = 0f;
        }

        debugRenderer.render(bossWorldManager.getWorld(), gameCamera.combined);
    }

    private void spawnBossAttacksBasedOnHealth() {
        int currentBossHP = boss.getHealth();

        int numberOfShards = 0;
        int numberOfBoulders = 0;
        float currentAttackInterval = 0;

        if (currentBossHP > PHASE_ONE_THRESHOLD) {
            numberOfShards = MathUtils.random(3, 4);
            numberOfBoulders = 0;
            currentAttackInterval = MathUtils.random(1.0f, 2.0f);
        } else if (currentBossHP > PHASE_TWO_THRESHOLD) {
            numberOfShards = 0;
            numberOfBoulders = MathUtils.random(2, 3);
            currentAttackInterval = MathUtils.random(0.8f, 1.5f);
        } else if (currentBossHP > 0){ // Фаза 3: 500 - 0 HP (Все вместе)
            numberOfShards = MathUtils.random(2, 3);
            numberOfBoulders = MathUtils.random(1, 2);
            currentAttackInterval = MathUtils.random(0.5f, 1.0f);
        } else {
            System.out.println("Boss umer!");
        }

        this.attackInterval = currentAttackInterval;

        for (int i = 0; i < numberOfShards; i++) {
            float spawnX = MathUtils.random(PLAYER_AREA_MIN_X, PLAYER_AREA_MAX_X);
            Vector2 spawnPosition = new Vector2(spawnX, SHARD_SPAWN_Y);
            BossAttack newAttack = new Shard(bossWorldManager.getWorld(), spawnPosition, shardTexture);
            bossAttacks.add(newAttack);

        }

        for (int i = 0; i < numberOfBoulders; i++) {
            float spawnY = MathUtils.random(BOULDER_SPAWN_Y_RANGE_MIN, BOULDER_SPAWN_Y_RANGE_MAX);
            boolean spawnFromLeft = MathUtils.randomBoolean();
            float spawnX = spawnFromLeft ? BOULDER_SPAWN_LEFT_X : BOULDER_SPAWN_RIGHT_X;

            Vector2 spawnPosition = new Vector2(spawnX, spawnY);
            BossAttack newAttack = new Boulder(bossWorldManager.getWorld(), spawnPosition, boulderTexture);
            bossAttacks.add(newAttack);
        }
    }


    @Override
    public void resize(int width, int height) {
        uiStage.getViewport().update(width, height, true);
        gameCamera.update();
        uiCamera.update();
    }

    @Override
    public void dispose() {
        batch.dispose();
        debugRenderer.dispose();
        renderer.dispose();
        uiStage.dispose();
        joystick.dispose();
        shardTexture.dispose();
        boulderTexture.dispose();


        Array<com.badlogic.gdx.physics.box2d.Body> bodies = new Array<>();
        bossWorldManager.getWorld().getBodies(bodies);
        for (com.badlogic.gdx.physics.box2d.Body body : bodies) {
            bossWorldManager.getWorld().destroyBody(body);
        }
        bossWorldManager.dispose();
    }

    public void pause() {
    }

    public void resume() {
    }

    public void hide() {
    }

    // Внутренний класс для обработки столкновений Box2D
    private class BossFightContactListener implements ContactListener {

        @Override
        public void beginContact(Contact contact) {
            Fixture fixtureA = contact.getFixtureA();
            Fixture fixtureB = contact.getFixtureB();

            // Извлекаем UserData из Body (это более распространено, чем из Fixture напрямую)
            Object userDataA = fixtureA.getBody().getUserData();
            Object userDataB = fixtureB.getBody().getUserData();

            // Пропускаем, если любой из userData равен null (например, столкновение с фикстурой карты без userData)
            if (userDataA == null || userDataB == null) return;

            // Столкновение: Пуля игрока + Босс
            if (userDataA instanceof PlayerBullet && userDataB instanceof Boss) {
                PlayerBullet bullet = (PlayerBullet) userDataA;
                Boss targetBoss = (Boss) userDataB;
                targetBoss.takeDamage(bullet.getDamage());
                bullet.markForRemoval();
            } else if (userDataB instanceof PlayerBullet && userDataA instanceof Boss) {
                PlayerBullet bullet = (PlayerBullet) userDataB;
                Boss targetBoss = (Boss) userDataA;
                targetBoss.takeDamage(bullet.getDamage());
                bullet.markForRemoval();
            }

            else if (userDataA instanceof BossAttack && userDataB instanceof MiniPlayer) {
                BossAttack attack = (BossAttack) userDataA;
                MiniPlayer targetPlayer = (MiniPlayer) userDataB;

                targetPlayer.takeDamage(attack.getDamage());

                attack.markForRemoval();
            } else if (userDataB instanceof BossAttack && userDataA instanceof MiniPlayer) {
                BossAttack attack = (BossAttack) userDataB;
                MiniPlayer targetPlayer = (MiniPlayer) userDataA;

                targetPlayer.takeDamage(attack.getDamage());

                attack.markForRemoval();
            }
        }


        @Override
        public void endContact(Contact contact) {
        }

        @Override
        public void preSolve(Contact contact, Manifold oldManifold) {
        }

        @Override
        public void postSolve(Contact contact, ContactImpulse impulse) {
        }
    }
}
