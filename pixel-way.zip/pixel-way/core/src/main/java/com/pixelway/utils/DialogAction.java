package com.pixelway.utils;

public interface DialogAction {
    void execute();
}
