package com.pixelway.models.dialogs;

import com.pixelway.utils.DialogAction;

public class DialogData {
    public String text;
    public String name;
    public String imagePath;
    public String option1 = null;
    public String option2 = null;
    public DialogData newDialogData = null;
    public DialogAction dialogAction = null;

    public DialogData(){}


}



